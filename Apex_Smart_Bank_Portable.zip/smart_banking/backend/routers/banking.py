from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
import random
from core.database import get_db
from core.deps import get_current_user
from models.user import User
from models.account import Account, AccountStatus
from models.transaction import Transaction, TransactionType, TransactionStatus
from models.fraud import FraudAlert
from schemas.banking import AccountCreate, AccountResponse, DepositWithdrawRequest, TransferRequest

router = APIRouter(prefix="/api/banking", tags=["Banking & Transactions"])

def evaluate_fraud_risk(user_id: int, amount: Decimal, db: Session) -> dict:
    risk_score = 15.0
    reason = "Normal transaction pattern verified by AI engine."

    if amount > Decimal("50000"):
        risk_score += 45.0
        reason = "Unusually large transaction amount exceeding safety threshold."

    recent_count = db.query(Transaction).filter(
        Transaction.sender_account_id.in_(
            db.query(Account.id).filter(Account.user_id == user_id)
        )
    ).count()

    if recent_count > 5:
        risk_score += 30.0
        reason = "High frequency of transactions in short duration."

    risk_score = min(risk_score, 100.0)

    if risk_score >= 70:
        category = "High"
    elif risk_score >= 40:
        category = "Medium"
    else:
        category = "Low"

    return {"risk_score": risk_score, "risk_category": category, "reason": reason}

@router.post("/accounts", response_model=AccountResponse, status_code=status.HTTP_201_CREATED)
def create_account(account_in: AccountCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    acc_num = "SB" + "".join([str(random.randint(0, 9)) for _ in range(8)])

    # Ensure unique account number
    while db.query(Account).filter(Account.account_number == acc_num).first():
        acc_num = "SB" + "".join([str(random.randint(0, 9)) for _ in range(8)])

    initial_dec = Decimal(str(account_in.initial_deposit))

    account = Account(
        account_number=acc_num,
        user_id=current_user.id,
        account_type=account_in.account_type,
        balance=initial_dec,
        status=AccountStatus.ACTIVE
    )
    db.add(account)
    db.commit()
    db.refresh(account)

    if initial_dec > 0:
        tx = Transaction(
            reference_number="REF" + "".join([str(random.randint(0, 9)) for _ in range(10)]),
            sender_account_id=None,
            receiver_account_id=account.id,
            transaction_type=TransactionType.DEPOSIT,
            amount=initial_dec,
            status=TransactionStatus.SUCCESS,
            description="Initial account opening deposit"
        )
        db.add(tx)
        db.commit()

    return account

@router.get("/accounts", response_model=List[AccountResponse])
def get_user_accounts(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(Account).filter(Account.user_id == current_user.id).all()

@router.get("/transactions")
def get_user_transactions(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    user_account_ids = [acc.id for acc in db.query(Account).filter(Account.user_id == current_user.id).all()]
    if not user_account_ids:
        return []

    txs = db.query(Transaction).filter(
        (Transaction.sender_account_id.in_(user_account_ids)) |
        (Transaction.receiver_account_id.in_(user_account_ids))
    ).order_by(Transaction.created_at.desc()).all()

    formatted = []
    for t in txs:
        is_credit = t.receiver_account_id in user_account_ids
        formatted.append({
            "id": t.id,
            "reference_number": t.reference_number,
            "type": "Credit" if is_credit else "Debit",
            "amount": float(t.amount),
            "description": t.description or t.transaction_type,
            "status": t.status,
            "created_at": t.created_at.strftime("%Y-%m-%d %H:%M")
        })
    return formatted

@router.post("/deposit", response_model=AccountResponse)
def deposit_money(req: DepositWithdrawRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    account = db.query(Account).filter(Account.account_number == req.account_number, Account.user_id == current_user.id).first()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    if account.status != AccountStatus.ACTIVE:
        raise HTTPException(status_code=400, detail="Account is inactive or frozen")

    amt = Decimal(str(req.amount))
    if amt <= 0:
        raise HTTPException(status_code=400, detail="Deposit amount must be greater than zero")

    account.balance += amt

    tx = Transaction(
        reference_number="REF" + "".join([str(random.randint(0, 9)) for _ in range(10)]),
        sender_account_id=None,
        receiver_account_id=account.id,
        transaction_type=TransactionType.DEPOSIT,
        amount=amt,
        status=TransactionStatus.SUCCESS,
        description="ATM / Branch Cash Deposit"
    )
    db.add(tx)
    db.commit()
    db.refresh(account)
    return account

@router.post("/withdraw", response_model=AccountResponse)
def withdraw_money(req: DepositWithdrawRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    account = db.query(Account).filter(Account.account_number == req.account_number, Account.user_id == current_user.id).first()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    if account.status != AccountStatus.ACTIVE:
        raise HTTPException(status_code=400, detail="Account is inactive or frozen")

    amt = Decimal(str(req.amount))
    if amt <= 0:
        raise HTTPException(status_code=400, detail="Withdrawal amount must be greater than zero")

    if account.balance < amt:
        raise HTTPException(status_code=400, detail="Insufficient balance")

    account.balance -= amt

    tx = Transaction(
        reference_number="REF" + "".join([str(random.randint(0, 9)) for _ in range(10)]),
        sender_account_id=account.id,
        receiver_account_id=None,
        transaction_type=TransactionType.WITHDRAWAL,
        amount=amt,
        status=TransactionStatus.SUCCESS,
        description="ATM Cash Withdrawal"
    )
    db.add(tx)
    db.commit()
    db.refresh(account)
    return account

@router.post("/transfer")
def transfer_money(req: TransferRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    amt = Decimal(str(req.amount))
    if amt <= 0:
        raise HTTPException(status_code=400, detail="Transfer amount must be greater than zero")

    if req.sender_account_number == req.receiver_account_number:
        raise HTTPException(status_code=400, detail="Cannot transfer funds to the same account")

    sender = db.query(Account).filter(Account.account_number == req.sender_account_number, Account.user_id == current_user.id).first()
    if not sender:
        raise HTTPException(status_code=404, detail="Sender account not found")

    if sender.status != AccountStatus.ACTIVE:
        raise HTTPException(status_code=400, detail="Sender account is inactive or frozen")

    # Robust receiver lookup across any valid active account in the bank database
    receiver = db.query(Account).filter(Account.account_number == req.receiver_account_number).first()
    if not receiver:
        raise HTTPException(status_code=404, detail=f"Receiver account '{req.receiver_account_number}' not found in Apex Bank system")

    if receiver.status != AccountStatus.ACTIVE:
        raise HTTPException(status_code=400, detail="Receiver account is inactive or frozen")

    if sender.balance < amt:
        raise HTTPException(status_code=400, detail="Insufficient funds for transfer")

    try:
        # Atomic database transaction block
        sender.balance -= amt
        receiver.balance += amt

        ref_num = "REF" + "".join([str(random.randint(0, 9)) for _ in range(10)])
        tx = Transaction(
            reference_number=ref_num,
            sender_account_id=sender.id,
            receiver_account_id=receiver.id,
            transaction_type=TransactionType.TRANSFER,
            amount=amt,
            status=TransactionStatus.SUCCESS,
            description=req.description
        )
        db.add(tx)
        db.commit()

        # AI Fraud Evaluation
        fraud_eval = evaluate_fraud_risk(current_user.id, amt, db)
        if fraud_eval["risk_score"] >= 40:
            alert = FraudAlert(
                transaction_id=tx.id,
                user_id=current_user.id,
                risk_score=fraud_eval["risk_score"],
                risk_category=fraud_eval["risk_category"],
                reason=fraud_eval["reason"],
                status="uninvestigated"
            )
            db.add(alert)
            db.commit()

        return {
            "message": "Transfer successful",
            "reference_number": ref_num,
            "amount": float(amt),
            "fraud_check": fraud_eval
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Transaction processing failed: {str(e)}")

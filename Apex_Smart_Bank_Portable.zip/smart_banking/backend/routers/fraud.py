from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from pydantic import BaseModel
from core.database import get_db
from core.deps import get_current_user, get_current_active_admin
from models.user import User
from models.fraud import FraudAlert
from models.transaction import Transaction

router = APIRouter(prefix="/api/fraud", tags=["AI Fraud Detection & Alerts"])

class FraudAlertResponse(BaseModel):
    id: int
    transaction_id: int
    user_id: int
    risk_score: float
    risk_category: str
    reason: str
    status: str

    class Config:
        from_attributes = True

@router.get("/alerts", response_model=List[FraudAlertResponse])
def get_fraud_alerts(admin_user: User = Depends(get_current_active_admin), db: Session = Depends(get_db)):
    return db.query(FraudAlert).order_by(FraudAlert.created_at.desc()).all()

@router.put("/alerts/{alert_id}/investigate")
def mark_investigated(alert_id: int, admin_user: User = Depends(get_current_active_admin), db: Session = Depends(get_db)):
    alert = db.query(FraudAlert).filter(FraudAlert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Fraud alert not found")

    alert.status = "investigated"
    db.commit()
    return {"message": "Alert marked as investigated successfully"}

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from core.database import get_db
from core.deps import get_current_user, get_current_active_admin
from models.user import User
from models.loan import Loan
from schemas.loan import LoanApplyRequest, LoanReviewRequest, LoanResponse

router = APIRouter(prefix="/api/loans", tags=["Loan Management & AI Analysis"])

@router.post("/", response_model=LoanResponse, status_code=status.HTTP_201_CREATED)
def apply_for_loan(loan_in: LoanApplyRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # AI credit risk evaluation
    risk_score = 0
    reason_parts = []

    income_to_loan_ratio = float(loan_in.monthly_income * 12) / float(loan_in.amount)
    if income_to_loan_ratio < 0.3:
        risk_score += 50
        reason_parts.append("Requested loan amount is high relative to annual income.")
    else:
        reason_parts.append("Healthy income-to-loan ratio.")

    if "salaried" in loan_in.employment_info.lower() or "permanent" in loan_in.employment_info.lower():
        reason_parts.append("Stable employment status.")
    else:
        risk_score += 20
        reason_parts.append("Employment stability verified as moderate risk.")

    if risk_score >= 50:
        category = "High"
    elif risk_score >= 25:
        category = "Medium"
    else:
        category = "Low"

    loan = Loan(
        user_id=current_user.id,
        loan_type=loan_in.loan_type,
        amount=loan_in.amount,
        monthly_income=loan_in.monthly_income,
        employment_info=loan_in.employment_info,
        status="pending",
        risk_category=category,
        ai_analysis_reason=" | ".join(reason_parts)
    )
    db.add(loan)
    db.commit()
    db.refresh(loan)
    return loan

@router.get("/", response_model=List[LoanResponse])
def get_user_loans(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if current_user.role == "admin":
        return db.query(Loan).all()
    return db.query(Loan).filter(Loan.user_id == current_user.id).all()

@router.put("/{loan_id}/review", response_model=LoanResponse)
def review_loan(loan_id: int, review_in: LoanReviewRequest, admin_user: User = Depends(get_current_active_admin), db: Session = Depends(get_db)):
    loan = db.query(Loan).filter(Loan.id == loan_id).first()
    if not loan:
        raise HTTPException(status_code=404, detail="Loan application not found")

    loan.status = review_in.status
    loan.admin_comments = review_in.admin_comments
    db.commit()
    db.refresh(loan)
    return loan

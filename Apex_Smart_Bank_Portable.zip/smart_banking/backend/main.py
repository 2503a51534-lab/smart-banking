from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from core.database import engine, Base
from routers import auth, banking, loans, fraud
import os

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Smart Banking & Financial Management System API",
    version="1.0.0",
    description="Backend API for customer management, auth, accounts, transactions, loans, AI credit analysis, and fraud detection."
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static folder for frontend UI
os.makedirs("static", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Include routers
app.include_router(auth.router)
app.include_router(banking.router)
app.include_router(loans.router)
app.include_router(fraud.router)

@app.get("/")
def serve_banking_ui():
    """Serves the Smart Banking React frontend dashboard directly."""
    # Try multiple paths for robustness
    for path in ["static/index.html", "smart_banking/backend/static/index.html"]:
        if os.path.exists(path):
            return FileResponse(path)
    return FileResponse("static/index.html")

if __name__ == "__main__":
    import uvicorn
    print("Starting Smart Banking & Financial Management System on http://127.0.0.1:8001 ...")
    uvicorn.main(["main:app", "--host", "127.0.0.1", "--port", "8001", "--reload"])

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from core.database import Base, get_db
from main import app

SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base.metadata.create_all(bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

def test_read_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["status"] == "online"

def test_register_and_login():
    # Register
    reg_response = client.post(
        "/api/auth/register",
        json={
            "email": "testbankuser@smart.com",
            "full_name": "Test Bank User",
            "password": "SecurePassword123",
            "role": "customer"
        }
    )
    assert reg_response.status_code == 201
    data = reg_response.json()
    assert data["email"] == "testbankuser@smart.com"
    assert "id" in data

    # Login
    login_response = client.post(
        "/api/auth/login",
        json={
            "email": "testbankuser@smart.com",
            "password": "SecurePassword123"
        }
    )
    assert login_response.status_code == 200
    token_data = login_response.json()
    assert "access_token" in token_data
    assert token_data["token_type"] == "bearer"

    # Read /me
    token = token_data["access_token"]
    me_response = client.get(
        "/api/auth/me",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert me_response.status_code == 200
    assert me_response.json()["email"] == "testbankuser@smart.com"

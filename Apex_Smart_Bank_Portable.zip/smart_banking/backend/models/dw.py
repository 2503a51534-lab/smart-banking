from sqlalchemy import Column, Integer, String, Numeric, ForeignKey, DateTime
from datetime import datetime
from core.database import Base

class DepositWithdraw(Base):
    __tablename__ = "deposits_withdrawals"

    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    tx_type = Column(String, nullable=False) # deposit or withdrawal
    amount = Column(Numeric(precision=15, scale=2), nullable=False)
    description = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

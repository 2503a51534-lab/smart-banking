from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime
from datetime import datetime
from core.database import Base

class FraudAlert(Base):
    __tablename__ = "fraud_alerts"

    id = Column(Integer, primary_key=True, index=True)
    transaction_id = Column(Integer, ForeignKey("transactions.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    risk_score = Column(Float, nullable=False) # 0 to 100
    risk_category = Column(String, nullable=False) # Low, Medium, High
    reason = Column(String, nullable=False)
    status = Column(String, default="uninvestigated", nullable=False) # uninvestigated, investigated
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

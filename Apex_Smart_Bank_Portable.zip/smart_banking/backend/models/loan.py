from sqlalchemy import Column, Integer, String, Numeric, ForeignKey, DateTime
from datetime import datetime
from core.database import Base

class Loan(Base):
    __tablename__ = "loans"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    loan_type = Column(String, nullable=False)
    amount = Column(Numeric(precision=15, scale=2), nullable=False)
    monthly_income = Column(Numeric(precision=15, scale=2), nullable=False)
    employment_info = Column(String, nullable=False)
    status = Column(String, default="pending", nullable=False) # pending, approved, rejected
    risk_category = Column(String, default="Medium", nullable=False)
    ai_analysis_reason = Column(String, nullable=True)
    admin_comments = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

from sqlalchemy import Column, Integer, String, Numeric, ForeignKey, DateTime, Enum
from datetime import datetime
import enum
from core.database import Base

class AccountType(str, enum.Enum):
    SAVINGS = "savings"
    CURRENT = "current"

class AccountStatus(str, enum.Enum):
    ACTIVE = "active"
    FROZEN = "frozen"
    CLOSED = "closed"

class Account(Base):
    __tablename__ = "accounts"

    id = Column(Integer, primary_key=True, index=True)
    account_number = Column(String, unique=True, index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    account_type = Column(String, default=AccountType.SAVINGS, nullable=False)
    balance = Column(Numeric(precision=15, scale=2), default=0.00, nullable=False)
    status = Column(String, default=AccountStatus.ACTIVE, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

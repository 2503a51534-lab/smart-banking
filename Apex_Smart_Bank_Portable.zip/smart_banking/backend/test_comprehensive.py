import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from core.database import Base, get_db
from main import app
from models.user import User
from models.account import Account, AccountStatus
from core.security import get_password_hash
from decimal import Decimal

SQLALCHEMY_DATABASE_URL = "sqlite:///./test_comprehensive.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base.metadata.drop_all(bind=engine)
Base.metadata.create_all(bind=engine)

def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db
client = TestClient(app)

def test_complete_transfer_matrix():
    # 1. Register test user & login
    client.post("/api/auth/register", json={"email": "sender_comp@apex.com", "full_name": "Sender Comprehensive", "password": "Password123"})
    login_res = client.post("/api/auth/login", json={"email": "sender_comp@apex.com", "password": "Password123"})
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # 2. Register receiver user
    client.post("/api/auth/register", json={"email": "receiver_comp@apex.com", "full_name": "Receiver Comprehensive", "password": "Password123"})

    # Seed accounts directly in test DB
    db = TestingSessionLocal()
    sender_user = db.query(User).filter(User.email == "sender_comp@apex.com").first()
    receiver_user = db.query(User).filter(User.email == "receiver_comp@apex.com").first()

    acc1 = Account(account_number="ACC48788922", user_id=sender_user.id, account_type="savings", balance=Decimal("500000.00"), status=AccountStatus.ACTIVE)
    acc2 = Account(account_number="ACC74882078", user_id=receiver_user.id, account_type="savings", balance=Decimal("1000.00"), status=AccountStatus.ACTIVE)
    db.add(acc1)
    db.add(acc2)
    db.commit()
    db.close()

    # A. Valid transfer of ₹20,000
    res = client.post("/api/banking/transfer", json={
        "sender_account_number": "ACC48788922",
        "receiver_account_number": "ACC74882078",
        "amount": 20000.00,
        "description": "Valid ₹20k transfer"
    }, headers=headers)
    assert res.status_code == 200
    data = res.json()
    assert data["message"] == "Transfer successful"
    assert data["amount"] == 20000.00

    # Verify balances in DB
    db = TestingSessionLocal()
    updated_acc1 = db.query(Account).filter(Account.account_number == "ACC48788922").first()
    updated_acc2 = db.query(Account).filter(Account.account_number == "ACC74882078").first()
    assert updated_acc1.balance == Decimal("480000.00")
    assert updated_acc2.balance == Decimal("21000.00")
    db.close()

    # B. Invalid receiver account (404)
    res_b = client.post("/api/banking/transfer", json={
        "sender_account_number": "ACC48788922",
        "receiver_account_number": "ACC99999999",
        "amount": 1000.00
    }, headers=headers)
    assert res_b.status_code == 404
    assert "not found" in res_b.json()["detail"]

    # C. Insufficient balance (400)
    res_c = client.post("/api/banking/transfer", json={
        "sender_account_number": "ACC48788922",
        "receiver_account_number": "ACC74882078",
        "amount": 9999999.00
    }, headers=headers)
    assert res_c.status_code == 400
    assert "Insufficient" in res_c.json()["detail"]

    # D. Zero amount (422 Pydantic or 400)
    res_d = client.post("/api/banking/transfer", json={
        "sender_account_number": "ACC48788922",
        "receiver_account_number": "ACC74882078",
        "amount": 0.00
    }, headers=headers)
    assert res_d.status_code in [400, 422]

    # E. Negative amount (422 Pydantic or 400)
    res_e = client.post("/api/banking/transfer", json={
        "sender_account_number": "ACC48788922",
        "receiver_account_number": "ACC74882078",
        "amount": -500.00
    }, headers=headers)
    assert res_e.status_code in [400, 422]

    # F. Transfer to the same account (400)
    res_f = client.post("/api/banking/transfer", json={
        "sender_account_number": "ACC48788922",
        "receiver_account_number": "ACC48788922",
        "amount": 1000.00
    }, headers=headers)
    assert res_f.status_code == 400
    assert "same account" in res_f.json()["detail"]

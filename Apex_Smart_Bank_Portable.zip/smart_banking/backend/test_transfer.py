import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from core.database import Base, get_db
from main import app
from models.user import User
from models.account import Account, AccountStatus
from core.security import get_password_hash
from decimal import Decimal

SQLALCHEMY_DATABASE_URL = "sqlite:///./test_transfer_isolated.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base.metadata.drop_all(bind=engine)
Base.metadata.create_all(bind=engine)

def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db
client = TestClient(app)

def test_transfer_scenarios():
    db = TestingSessionLocal()
    user1 = User(email="sender@apex.com", full_name="Sender User", hashed_password=get_password_hash("Password123"), role="customer")
    user2 = User(email="receiver@apex.com", full_name="Receiver User", hashed_password=get_password_hash("Password123"), role="customer")
    db.add(user1)
    db.add(user2)
    db.commit()

    acc1 = Account(account_number="SB11111111", user_id=user1.id, account_type="savings", balance=Decimal("500000.00"), status=AccountStatus.ACTIVE)
    acc2 = Account(account_number="SB22222222", user_id=user2.id, account_type="savings", balance=Decimal("1000.00"), status=AccountStatus.ACTIVE)
    db.add(acc1)
    db.add(acc2)
    db.commit()
    db.close()

    login_res = client.post("/api/auth/login", json={"email": "sender@apex.com", "password": "Password123"})
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # Test Scenario A: Successful transfer
    res = client.post("/api/banking/transfer", json={
        "sender_account_number": "SB11111111",
        "receiver_account_number": "SB22222222",
        "amount": 9976.00,
        "description": "Test Transfer"
    }, headers=headers)
    assert res.status_code == 200
    assert res.json()["message"] == "Transfer successful"

    # Test Scenario B: Nonexistent receiver account
    res_non = client.post("/api/banking/transfer", json={
        "sender_account_number": "SB11111111",
        "receiver_account_number": "SB99999999",
        "amount": 100.00
    }, headers=headers)
    assert res_non.status_code == 404
    assert "not found" in res_non.json()["detail"]

    # Test Scenario C: Same account transfer
    res_same = client.post("/api/banking/transfer", json={
        "sender_account_number": "SB11111111",
        "receiver_account_number": "SB11111111",
        "amount": 100.00
    }, headers=headers)
    assert res_same.status_code == 400

    # Test Scenario D: Insufficient funds
    res_ins = client.post("/api/banking/transfer", json={
        "sender_account_number": "SB11111111",
        "receiver_account_number": "SB22222222",
        "amount": 9999999.00
    }, headers=headers)
    assert res_ins.status_code == 400

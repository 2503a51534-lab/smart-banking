from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class AccountCreate(BaseModel):
    account_type: str = Field(..., description="savings or current")
    initial_deposit: float = Field(default=0.00, ge=0.0)

class AccountResponse(BaseModel):
    id: int
    account_number: str
    user_id: int
    account_type: str
    balance: float
    status: str
    created_at: datetime

    class Config:
        from_attributes = True

class DepositWithdrawRequest(BaseModel):
    account_number: str
    amount: float = Field(..., gt=0.0)

class TransferRequest(BaseModel):
    sender_account_number: str
    receiver_account_number: str
    amount: float = Field(..., gt=0.0)
    description: Optional[str] = "Money Transfer"

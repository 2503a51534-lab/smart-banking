from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class LoanApplyRequest(BaseModel):
    loan_type: str = Field(..., description="Personal, Home, Auto, Business")
    amount: float = Field(..., gt=0.0)
    monthly_income: float = Field(..., gt=0.0)
    employment_info: str

class LoanReviewRequest(BaseModel):
    status: str = Field(..., description="approved or rejected")
    admin_comments: Optional[str] = None

class LoanResponse(BaseModel):
    id: int
    user_id: int
    loan_type: str
    amount: float
    monthly_income: float
    employment_info: str
    status: str
    risk_category: str
    ai_analysis_reason: Optional[str]
    admin_comments: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True

# Apex Smart Bank — Setup Guide

## Important
This is an academic demonstration/simulation project. It is not connected to a real bank or payment network. Use fictional test information and virtual balances only.

## Included in this package
- FastAPI backend
- Browser interface served from `backend/static/index.html`
- Existing Python dependency list (`backend/requirements.txt`)
- Existing application modules and test source files

The original application source files have been copied without editing. Local virtual environments, cache files, local database files, and the original `.env` file are not included.

## Requirements
- Windows 10 or Windows 11
- Python 3.12 recommended
- Internet connection for installing Python packages and loading the browser interface's CDN-hosted libraries

Install Python 3.12 from https://www.python.org/downloads/ if it is not already installed. During installation, enable **Add Python to PATH**.

## Setup and run

1. Extract `Apex_Smart_Bank_Portable.zip`.
2. Open PowerShell in the extracted `smart_banking` folder.
3. Run:

```powershell
cd backend
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8001
```

If PowerShell blocks activation, you can avoid activation and run:

```powershell
cd backend
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn main:app --reload --host 127.0.0.1 --port 8001
```

4. Keep the PowerShell window open.
5. Open these addresses in a browser:
   - Application: http://127.0.0.1:8001/
   - API documentation: http://127.0.0.1:8001/docs

The backend is configured to use SQLite by default. It creates its database tables when the application starts. The database file will be created locally in the backend folder on the new computer.

## Troubleshooting

- **`py -3.12` is not recognized:** Install Python 3.12 and reopen PowerShell.
- **Package installation fails:** Check the Python version and internet connection. Some scientific packages may take longer to install.
- **Port 8001 is already in use:** Stop the other application using that port, or run Uvicorn with another port and use that same port in the browser.
- **Browser cannot connect:** Make sure the Uvicorn process is still running and open the application URL shown above.
- **Interface cannot load external libraries:** Check the internet connection because the existing HTML loads some libraries from public CDNs.

## Security and data notes

- This package intentionally excludes the original `.env` and local database files.
- The existing source code contains a fallback development secret key. This project should only be used as a local academic demo; do not expose it publicly or use real personal or financial information.
- Do not add real passwords, API keys, customer data, or private banking information to this package.
- Each person should use their own local test data.

## Project source
The application source code is included as received. No application source code was intentionally modified while preparing this distribution package.
